package com.brainboost.mathgame

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Purple = Color(0xFF6C4DFF)
val Pink = Color(0xFFFF4D9D)
val Orange = Color(0xFFFFA726)
val Green = Color(0xFF2ECC71)
val Red = Color(0xFFE74C3C)
val Blue = Color(0xFF29B6F6)

sealed interface Screen {
    data object Home : Screen
    data object Levels : Screen
    data object Shop : Screen
    data object Daily : Screen
    data object Settings : Screen
    data class Play(val level: Int) : Screen
    data class Result(val level: Int, val correct: Int, val total: Int) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ads.init(this)
        val store = Store(this)
        setContent { App(store, this) }
    }
}

// ---------- helpers ----------
fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_SHORT).show()

fun fx(c: Context, s: Store, ok: Boolean) {
    try {
        if (s.sound) {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 150)
            Handler(Looper.getMainLooper()).postDelayed({ tg.release() }, 500)
        }
        if (s.vib) {
            @Suppress("DEPRECATION")
            (c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(if (ok) 30L else 120L)
        }
    } catch (_: Exception) {}
}

/** Reward صرف Unity کے Completion Callback پر ملتا ہے */
fun watchAd(act: Activity, onEnd: () -> Unit = {}, onReward: () -> Unit) {
    Ads.show(act, AdsConfig.REWARDED) { ok ->
        onEnd()
        if (ok) onReward() else toast(act, "Ad not available or not completed - no reward")
    }
}

@Composable
fun Btn(
    text: String, c1: Color, c2: Color = c1, modifier: Modifier = Modifier,
    enabled: Boolean = true, alpha: Float = 1f, fs: Int = 17, onClick: () -> Unit
) {
    Box(
        modifier.height(52.dp).alpha(alpha).clip(RoundedCornerShape(26.dp))
            .background(Brush.horizontalGradient(listOf(c1, c2)))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = fs.sp, textAlign = TextAlign.Center) }
}

@Composable
fun Card2(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.18f)).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, content = content
    )
}

@Composable
fun W(text: String, size: Int = 16, bold: Boolean = false, modifier: Modifier = Modifier) =
    Text(text, color = Color.White, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        textAlign = TextAlign.Center, modifier = modifier)

@Composable
fun TopBar(title: String, s: Store, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("←", color = Color.White, fontSize = 28.sp, modifier = Modifier.clickable { onBack() }.padding(end = 14.dp))
        W(title, 22, true)
        Spacer(Modifier.weight(1f))
        W("🪙 ${s.coins}", 18, true)
    }
}

// ---------- root ----------
@Composable
fun App(s: Store, act: Activity) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val bg = if (s.dark) listOf(Color(0xFF14123A), Color(0xFF2A1B5E)) else listOf(Color(0xFF7C5CFF), Color(0xFFFF7EB3))
    MaterialTheme(colorScheme = if (s.dark) darkColorScheme() else lightColorScheme()) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(bg))) {
            Box(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
                BackHandler(enabled = screen != Screen.Home) {
                    val sc = screen
                    if (sc is Screen.Play) screen = Screen.Levels
                    else if (sc !is Screen.Result) screen = Screen.Home
                }
                when (val sc = screen) {
                    Screen.Home -> HomeScreen(s) { screen = it }
                    Screen.Levels -> LevelsScreen(s, act, { screen = Screen.Play(it) }, { screen = Screen.Home })
                    Screen.Shop -> ShopScreen(s, act) { screen = Screen.Home }
                    Screen.Daily -> DailyScreen(s, act) { screen = Screen.Home }
                    Screen.Settings -> SettingsScreen(s) { screen = Screen.Home }
                    is Screen.Play -> GameScreen(sc.level, s, act,
                        { c, t -> screen = Screen.Result(sc.level, c, t) }, { screen = Screen.Levels })
                    is Screen.Result -> ResultScreen(sc, s, act) { screen = Screen.Levels }
                }
            }
            Banner(act)
        }
    }
}

// ---------- Home ----------
@Composable
fun HomeScreen(s: Store, go: (Screen) -> Unit) {
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        1f, 1.08f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(120.dp).scale(pulse).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Orange, Pink, Purple))), contentAlignment = Alignment.Center) {
                Text("🧠", fontSize = 62.sp)
            }
            Spacer(Modifier.height(10.dp))
            W("Brain Boost", 36, true)
            W("MINI", 18, true)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Card2(Modifier.weight(1f)) { W("🪙 Coins"); W("${s.coins}", 24, true) }
            Card2(Modifier.weight(1f)) { W("🎯 Level"); W("${s.current + 1}", 24, true) }
        }
        Btn("▶  PLAY", Green, Blue, Modifier.fillMaxWidth().height(64.dp), fs = 24) { go(Screen.Levels) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn(if (s.canClaim()) "🎁 Daily •" else "🎁 Daily", Orange, Pink, Modifier.weight(1f), fs = 14) { go(Screen.Daily) }
            Btn("🛒 Shop", Purple, Blue, Modifier.weight(1f), fs = 14) { go(Screen.Shop) }
            Btn("⚙ Settings", Blue, Purple, Modifier.weight(1f), fs = 14) { go(Screen.Settings) }
        }
    }
}

// ---------- Levels ----------
@Composable
fun LevelsScreen(s: Store, act: Activity, onPlay: (Int) -> Unit, onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(s.current / 25) }
    var lock by remember { mutableStateOf<Int?>(null) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Levels", s, onBack)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 10.dp)) {
            Game.OPS.forEachIndexed { i, o ->
                Btn(o.second, if (tab == i) Orange else Color(0x55FFFFFF), modifier = Modifier.weight(1f),
                    fs = 22) { tab = i }
            }
        }
        W(Game.OPS[tab].first, 18, true, Modifier.padding(bottom = 8.dp))
        LazyVerticalGrid(GridCells.Fixed(5), Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items((0 until 25).toList()) { i ->
                val l = tab * 25 + i
                val open = l in s.unlocked
                val st = s.stars[l] ?: 0
                Column(
                    Modifier.clip(RoundedCornerShape(14.dp))
                        .background(if (open) Brush.linearGradient(listOf(Blue, Purple)) else Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x44FFFFFF))))
                        .clickable { if (open) onPlay(l) else lock = l }.padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    W(if (open) "${i + 1}" else "🔒", 18, true)
                    W(if (st > 0) "★".repeat(st) else "·", 11)
                }
            }
        }
    }
    lock?.let { l ->
        AlertDialog(
            onDismissRequest = { lock = null },
            title = { Text("Locked Level") },
            text = { Text("Unlock this level for ${Store.UNLOCK_COST} coins?") },
            confirmButton = {
                TextButton({
                    if (s.spend(Store.UNLOCK_COST)) s.unlock(l) else toast(act, "Not enough coins")
                    lock = null
                }) { Text("Unlock") }
            },
            dismissButton = { TextButton({ lock = null }) { Text("Cancel") } }
        )
    }
}

// ---------- Game ----------
@Composable
fun GameScreen(level: Int, s: Store, act: Activity, onDone: (Int, Int) -> Unit, onExit: () -> Unit) {
    val qs = remember(level) { Game.questions(level) }
    var idx by remember { mutableIntStateOf(0) }
    var correct by remember { mutableIntStateOf(0) }
    var time by remember { mutableIntStateOf(20) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var hidden by remember { mutableStateOf(setOf<Int>()) }
    var paused by remember { mutableStateOf(false) }
    val q = qs[idx]
    val scope = rememberCoroutineScope()

    fun advance(chosen: Int?) {
        if (picked != null) return
        picked = chosen ?: -1
        val ok = chosen == q.answer
        if (ok) correct++
        fx(act, s, ok)
        scope.launch {
            delay(700)
            if (idx + 1 >= qs.size) onDone(correct, qs.size)
            else { idx++; picked = null; hidden = emptySet(); time = 20 }
        }
    }

    LaunchedEffect(idx) {
        while (true) {
            delay(1000)
            if (!paused && picked == null) {
                time--
                if (time <= 0) { time = 0; advance(null) }
            }
        }
    }

    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("✕", color = Color.White, fontSize = 26.sp, modifier = Modifier.clickable { onExit() }.padding(end = 12.dp))
            W("${Game.OPS[level / 25].first} • Level ${level % 25 + 1}", 16, true)
            Spacer(Modifier.weight(1f))
            W("🪙 ${s.coins}", 18, true)
        }
        LinearProgressIndicator(progress = { idx.toFloat() / qs.size }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
            color = Orange, trackColor = Color(0x44FFFFFF))
        Row {
            W("Question ${idx + 1}/${qs.size}", 14)
            Spacer(Modifier.weight(1f))
            W("⏱ ${time.coerceAtLeast(0)}s", 16, true)
        }
        Card2(Modifier.fillMaxWidth().weight(1f)) {
            Spacer(Modifier.weight(1f))
            W(q.text, 44, true)
            Spacer(Modifier.weight(1f))
        }
        for (row in q.options.chunked(2)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (o in row) {
                    val hide = o in hidden
                    val (c1, c2) = when {
                        picked == null -> Blue to Purple
                        o == q.answer -> Green to Green
                        o == picked -> Red to Red
                        else -> Color(0x66FFFFFF) to Color(0x66FFFFFF)
                    }
                    Btn("$o", c1, c2, Modifier.weight(1f).height(72.dp), enabled = picked == null && !hide,
                        alpha = if (hide) 0f else 1f, fs = 26) { advance(o) }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            // Hint
            Btn(
                when { s.hints > 0 -> "💡 Hint (${s.hints})"; s.canHint -> "💡 Hint ${Store.HINT_COST}🪙"; else -> "💡 Free Hint (Ad)" },
                Orange, Pink, Modifier.weight(1f), fs = 14
            ) {
                if (picked != null || hidden.isNotEmpty()) return@Btn
                val give = { hidden = q.options.filter { it != q.answer }.shuffled().take(2).toSet() }
                if (s.canHint) { if (s.useHint()) give() }
                else { paused = true; watchAd(act, { paused = false }) { give() } }
            }
            // Extra time
            Btn(
                when { s.times > 0 -> "⏱ +10s (${s.times})"; s.canTime -> "⏱ +10s ${Store.TIME_COST}🪙"; else -> "⏱ +10s (Ad)" },
                Blue, Purple, Modifier.weight(1f), fs = 14
            ) {
                if (picked != null) return@Btn
                if (s.canTime) { if (s.useTime()) time += 10 }
                else { paused = true; watchAd(act, { paused = false }) { time += 10 } }
            }
        }
    }
}

// ---------- Result ----------
@Composable
fun ResultScreen(r: Screen.Result, s: Store, act: Activity, onExit: () -> Unit) {
    val pct = r.correct * 100 / r.total
    val stars = if (pct >= 90) 3 else if (pct >= 60) 2 else 1
    val coins = when (stars) { 3 -> 50; 2 -> 30; else -> 20 }
    var busy by remember { mutableStateOf(false) }
    var target by remember { mutableIntStateOf(0) }
    val shown by animateIntAsState(target, tween(900), label = "c")
    LaunchedEffect(Unit) { s.finish(r.level, stars); target = coins }

    fun leave() {
        val groupEnd = r.level % 25 == 24
        if (s.completed % 3 == 0 || groupEnd) Ads.show(act, AdsConfig.INTERSTITIAL) { onExit() } else onExit()
    }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly) {
        W("Level Completed!", 32, true)
        W("★".repeat(stars) + "☆".repeat(3 - stars), 48)
        W("Correct: ${r.correct}/${r.total}", 18)
        Card2(Modifier.fillMaxWidth()) {
            W("You Earned $shown Coins! 🪙", 24, true)
        }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Btn("Collect Coins", Green, Blue, Modifier.fillMaxWidth(), enabled = !busy) {
                busy = true; s.addCoins(coins); leave()
            }
            Btn("📺 Watch Ad & Double Coins", Orange, Pink, Modifier.fillMaxWidth(), enabled = !busy) {
                busy = true
                Ads.show(act, AdsConfig.REWARDED) { ok ->
                    if (ok) { s.addCoins(coins * 2); leave() }
                    else { busy = false; toast(act, "Ad not available or not completed - no reward") }
                }
            }
        }
    }
}

// ---------- Daily ----------
@Composable
fun DailyScreen(s: Store, act: Activity, onBack: () -> Unit) {
    val done = s.doneDays()
    val next = s.nextIdx()
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TopBar("Daily Reward", s, onBack)
        for (row in Game.DAILY.withIndex().toList().chunked(4)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for ((i, v) in row) {
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                            .background(if (i < done) Green.copy(alpha = 0.7f) else if (i == next && s.canClaim()) Orange else Color(0x33FFFFFF))
                            .padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) { W("Day ${i + 1}", 12); W("🪙", 22); W("$v", 16, true) }
                }
                if (row.size < 4) Spacer(Modifier.weight((4 - row.size).toFloat()))
            }
        }
        Spacer(Modifier.weight(1f))
        if (s.canClaim()) {
            Btn("🎁 Claim ${Game.DAILY[next]} Coins", Green, Blue, Modifier.fillMaxWidth()) {
                val a = s.claim(1); toast(act, "+$a coins!")
            }
            Btn("📺 Watch Ad & Claim x2", Orange, Pink, Modifier.fillMaxWidth()) {
                watchAd(act) { val a = s.claim(2); toast(act, "+$a coins!") }
            }
        } else W("✅ Today's reward collected. Come back tomorrow!", 16, true, Modifier.fillMaxWidth())
        Spacer(Modifier.weight(1f))
    }
}

// ---------- Shop ----------
@Composable
fun ShopScreen(s: Store, act: Activity, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TopBar("Shop", s, onBack)
        Card2(Modifier.fillMaxWidth()) {
            W("🪙 Free Coins", 18, true); W("Watch a short ad: +50 coins")
            Spacer(Modifier.height(8.dp))
            Btn("📺 Watch Ad", Orange, Pink, Modifier.fillMaxWidth()) {
                watchAd(act) { s.addCoins(50); toast(act, "+50 coins!") }
            }
        }
        Card2(Modifier.fillMaxWidth()) {
            W("💡 Hint Pack x3  (you have ${s.hints})", 18, true)
            Spacer(Modifier.height(8.dp))
            Btn("Buy for 25 🪙", Blue, Purple, Modifier.fillMaxWidth()) {
                if (!s.buyHints(3, 25)) toast(act, "Not enough coins")
            }
        }
        Card2(Modifier.fillMaxWidth()) {
            W("⏱ Extra Time Pack x3  (you have ${s.times})", 18, true)
            Spacer(Modifier.height(8.dp))
            Btn("Buy for 30 🪙", Blue, Purple, Modifier.fillMaxWidth()) {
                if (!s.buyTimes(3, 30)) toast(act, "Not enough coins")
            }
        }
        W("Locked levels can be unlocked from the Levels screen (${Store.UNLOCK_COST} coins).", 13)
    }
}

// ---------- Settings ----------
@Composable
fun SettingsScreen(s: Store, onBack: () -> Unit) {
    var dlg by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TopBar("Settings", s, onBack)
        Card2(Modifier.fillMaxWidth()) {
            SwitchRow("🔊 Sound", s.sound) { s.updateSound(it) }
            SwitchRow("📳 Vibration", s.vib) { s.updateVib(it) }
            SwitchRow("🌙 Dark Mode", s.dark) { s.updateDark(it) }
        }
        Btn("Privacy Policy", Blue, Purple, Modifier.fillMaxWidth()) { dlg = "privacy" }
        Btn("About", Blue, Purple, Modifier.fillMaxWidth()) { dlg = "about" }
    }
    dlg?.let { d ->
        AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text(if (d == "privacy") "Privacy Policy" else "About") },
            text = {
                Text(
                    if (d == "privacy")
                        "Brain Boost Mini stores your coins, level progress and settings only on your device. " +
                        "It has no accounts and collects no personal data itself. " +
                        "Ads are served by Unity Ads, which may use your device's advertising ID to show ads; " +
                        "see Unity's privacy policy for details."
                    else "Brain Boost Mini v1.0\nA small offline math brain-training game with 100 levels."
                )
            },
            confirmButton = { TextButton({ dlg = null }) { Text("OK") } }
        )
    }
}

@Composable
fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        W(label, 18)
        Spacer(Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}
