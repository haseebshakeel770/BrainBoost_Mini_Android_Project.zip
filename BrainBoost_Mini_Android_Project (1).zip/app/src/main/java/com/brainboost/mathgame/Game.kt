package com.brainboost.mathgame

import android.content.Context
import androidx.compose.runtime.*
import java.util.TimeZone
import kotlin.random.Random

data class Q(val text: String, val answer: Int, val options: List<Int>)

object Game {
    val OPS = listOf("Addition" to "+", "Subtraction" to "−", "Multiplication" to "×", "Division" to "÷")
    val DAILY = listOf(20, 30, 50, 70, 100, 150, 200)

    /** Level 0..99 → 4 operations × 25 levels. 5 سے 9 سوالات۔ */
    fun count(level: Int) = 5 + (level % 25) / 5

    fun questions(level: Int): List<Q> = List(count(level)) { make(level / 25, level % 25) }

    private fun make(op: Int, n: Int): Q {
        val r = Random
        val a: Int
        val b: Int
        val ans: Int
        when (op) {
            0 -> { val m = 10 + n * 8; a = r.nextInt(1, m + 1); b = r.nextInt(1, m + 1); ans = a + b }
            1 -> { val m = 10 + n * 8; a = r.nextInt(2, m + 2); b = r.nextInt(1, a); ans = a - b }
            2 -> { a = r.nextInt(2, 4 + n / 2 + 1); b = r.nextInt(2, 6 + n / 2 + 1); ans = a * b }
            else -> { b = r.nextInt(2, 4 + n / 2 + 1); val q = r.nextInt(2, 5 + n / 2 + 1); a = b * q; ans = q }
        }
        val opts = mutableSetOf(ans)
        while (opts.size < 4) {
            val w = ans + r.nextInt(1, 11) * (if (r.nextBoolean()) 1 else -1)
            if (w >= 0) opts.add(w)
        }
        return Q("$a ${OPS[op].second} $b = ?", ans, opts.shuffled())
    }
}

/** تمام محفوظ ڈیٹا (SharedPreferences) — Coins، Levels، Daily، Settings */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("bb", Context.MODE_PRIVATE)

    var coins by mutableIntStateOf(p.getInt("coins", 0)); private set
    var hints by mutableIntStateOf(p.getInt("hints", 0)); private set
    var times by mutableIntStateOf(p.getInt("times", 0)); private set
    var completed by mutableIntStateOf(p.getInt("done", 0)); private set
    var lastDay by mutableLongStateOf(p.getLong("lastDay", -1L)); private set
    var streak by mutableIntStateOf(p.getInt("streak", 0)); private set
    var stars by mutableStateOf(
        p.getString("stars", "")!!.split(";").filter { it.contains(":") }
            .associate { val (a, b) = it.split(":"); a.toInt() to b.toInt() }
    ); private set
    var unlocked by mutableStateOf(
        p.getString("unl", "0")!!.split(",").mapNotNull { it.toIntOrNull() }.toSet() + 0
    ); private set
    var sound by mutableStateOf(p.getBoolean("snd", true)); private set
    var vib by mutableStateOf(p.getBoolean("vib", true)); private set
    var dark by mutableStateOf(p.getBoolean("dark", false)); private set

    val current: Int get() = (0..99).firstOrNull { it in unlocked && (stars[it] ?: 0) == 0 } ?: 99

    fun addCoins(n: Int) { coins += n; p.edit().putInt("coins", coins).apply() }
    fun spend(n: Int): Boolean {
        if (coins < n) return false
        coins -= n; p.edit().putInt("coins", coins).apply(); return true
    }
    fun buyHints(n: Int, price: Int): Boolean {
        if (!spend(price)) return false
        hints += n; p.edit().putInt("hints", hints).apply(); return true
    }
    fun buyTimes(n: Int, price: Int): Boolean {
        if (!spend(price)) return false
        times += n; p.edit().putInt("times", times).apply(); return true
    }
    /** پہلے Stock، پھر Coins */
    fun useHint(): Boolean {
        if (hints > 0) { hints--; p.edit().putInt("hints", hints).apply(); return true }
        return spend(HINT_COST)
    }
    fun useTime(): Boolean {
        if (times > 0) { times--; p.edit().putInt("times", times).apply(); return true }
        return spend(TIME_COST)
    }
    val canHint get() = hints > 0 || coins >= HINT_COST
    val canTime get() = times > 0 || coins >= TIME_COST

    fun unlock(level: Int) {
        unlocked = unlocked + level
        p.edit().putString("unl", unlocked.joinToString(",")).apply()
    }
    fun finish(level: Int, st: Int) {
        stars = stars + (level to maxOf(st, stars[level] ?: 0))
        p.edit().putString("stars", stars.entries.joinToString(";") { "${it.key}:${it.value}" }).apply()
        if (level < 99) unlock(level + 1)
        completed++; p.edit().putInt("done", completed).apply()
    }

    fun updateSound(v: Boolean) { sound = v; p.edit().putBoolean("snd", v).apply() }
    fun updateVib(v: Boolean) { vib = v; p.edit().putBoolean("vib", v).apply() }
    fun updateDark(v: Boolean) { dark = v; p.edit().putBoolean("dark", v).apply() }

    // ---- Daily Reward ----
    private fun today(): Long {
        val n = System.currentTimeMillis()
        return (n + TimeZone.getDefault().getOffset(n)) / 86400000L
    }
    fun canClaim() = lastDay != today()
    fun nextIdx(): Int = when (lastDay) {
        today() - 1 -> streak % 7
        today() -> (streak - 1) % 7
        else -> 0
    }
    /** کتنے دن کے Rewards لیے جا چکے (Display کے لیے) */
    fun doneDays(): Int = when (lastDay) {
        today() -> (streak - 1) % 7 + 1
        today() - 1 -> streak % 7
        else -> 0
    }
    fun claim(mult: Int): Int {
        if (!canClaim()) return 0
        val amt = Game.DAILY[nextIdx()] * mult
        streak = if (lastDay == today() - 1) streak + 1 else 1
        lastDay = today()
        p.edit().putInt("streak", streak).putLong("lastDay", lastDay).apply()
        addCoins(amt)
        return amt
    }

    companion object { const val HINT_COST = 10; const val TIME_COST = 15; const val UNLOCK_COST = 50 }
}
