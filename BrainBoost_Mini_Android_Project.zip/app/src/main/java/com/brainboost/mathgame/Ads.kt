package com.brainboost.mathgame

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.unity3d.ads.IUnityAdsInitializationListener
import com.unity3d.ads.IUnityAdsLoadListener
import com.unity3d.ads.IUnityAdsShowListener
import com.unity3d.ads.UnityAds
import com.unity3d.ads.UnityAdsShowOptions
import com.unity3d.services.banners.BannerErrorInfo
import com.unity3d.services.banners.BannerView
import com.unity3d.services.banners.UnityBannerSize

object Ads {
    var ready by mutableStateOf(false)
        private set
    private val loaded = mutableSetOf<String>()

    fun init(ctx: Context) {
        if (AdsConfig.GAME_ID.isBlank()) return
        UnityAds.initialize(ctx.applicationContext, AdsConfig.GAME_ID, AdsConfig.TEST_MODE,
            object : IUnityAdsInitializationListener {
                override fun onInitializationComplete() {
                    ready = true
                    load(AdsConfig.INTERSTITIAL)
                    load(AdsConfig.REWARDED)
                }
                override fun onInitializationFailed(error: UnityAds.UnityAdsInitializationError?, message: String?) {}
            })
    }

    private fun load(id: String) {
        if (!ready || id.isBlank()) return
        UnityAds.load(id, object : IUnityAdsLoadListener {
            override fun onUnityAdsAdLoaded(placementId: String?) { loaded.add(id) }
            override fun onUnityAdsFailedToLoad(placementId: String?, error: UnityAds.UnityAdsLoadError?, message: String?) {}
        })
    }

    /** onResult(true) = اشتہار مکمل دیکھا گیا (COMPLETED). ورنہ false۔ */
    fun show(act: Activity, id: String, onResult: (Boolean) -> Unit) {
        if (!ready || id.isBlank() || !loaded.contains(id)) {
            load(id); onResult(false); return
        }
        loaded.remove(id)
        UnityAds.show(act, id, UnityAdsShowOptions(), object : IUnityAdsShowListener {
            override fun onUnityAdsShowFailure(placementId: String?, error: UnityAds.UnityAdsShowError?, message: String?) {
                load(id); onResult(false)
            }
            override fun onUnityAdsShowStart(placementId: String?) {}
            override fun onUnityAdsShowClick(placementId: String?) {}
            override fun onUnityAdsShowComplete(placementId: String?, state: UnityAds.UnityAdsShowCompletionState?) {
                load(id)
                onResult(state == UnityAds.UnityAdsShowCompletionState.COMPLETED)
            }
        })
    }
}

/** ایک ہی Banner پوری App میں (نیچے) — بار بار Initialize نہیں ہوتا۔ */
@Composable
fun Banner(act: Activity) {
    if (!Ads.ready || AdsConfig.BANNER.isBlank()) return
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        AndroidView(
            modifier = Modifier.height(50.dp),
            factory = { _ ->
                BannerView(act, AdsConfig.BANNER, UnityBannerSize(320, 50)).apply {
                    listener = object : BannerView.IListener {
                        override fun onBannerLoaded(bannerAdView: BannerView?) {}
                        override fun onBannerShown(bannerAdView: BannerView?) {}
                        override fun onBannerClick(bannerAdView: BannerView?) {}
                        override fun onBannerFailedToLoad(bannerAdView: BannerView?, errorInfo: BannerErrorInfo?) {}
                        override fun onBannerLeftApplication(bannerAdView: BannerView?) {}
                    }
                    load()
                }
            }
        )
    }
}
