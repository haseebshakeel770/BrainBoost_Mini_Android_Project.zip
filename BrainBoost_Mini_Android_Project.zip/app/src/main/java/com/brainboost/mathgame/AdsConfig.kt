package com.brainboost.mathgame

/**
 * ===== یہاں اپنی اصل Unity Dashboard کی IDs درج کریں =====
 * Unity Dashboard > Monetization > Ad Units (Android) سے Placement/Ad Unit IDs کاپی کریں۔
 * جب تک کوئی ID خالی ("") ہے، وہ اشتہار ظاہر نہیں ہوگا (App crash نہیں ہوگی)۔
 */
object AdsConfig {
    const val GAME_ID = "62251897"        // Android Game ID
    const val TEST_MODE = true            // Production کے لیے false کریں

    const val BANNER = ""                 // <-- Android Banner Ad Unit ID
    const val INTERSTITIAL = ""           // <-- Android Interstitial Ad Unit ID
    const val REWARDED = ""               // <-- Android Rewarded Ad Unit ID
}
