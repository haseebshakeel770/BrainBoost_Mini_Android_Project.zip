# Brain Boost Mini (com.brainboost.mathgame)

Small offline math game: 4 operations × 25 levels = 100 levels, coins, daily reward, hints, Unity Ads (banner / interstitial / rewarded).

## Unity Ad Unit IDs
`app/src/main/java/com/brainboost/mathgame/AdsConfig.kt` — Game ID is set (62251897). Paste your real Banner / Interstitial / Rewarded IDs from the Unity Dashboard. Empty ID = that ad is skipped. Set `TEST_MODE = false` for production.

## Build APK on GitHub
1. Create a repo, upload the *contents* of this folder (the `.github` folder must be at repo root).
2. Actions tab → "Build APK" → run → download artifact `BrainBoostMini-APK` (debug APK).

Local: open in Android Studio, or `gradle assembleDebug` (Gradle 8.7, JDK 17).
